Sample: JMS Sample
===============

Introduction
============

This sample demonstrate use of JMS transport in both server and client sides. Axis2 Simple Server Maven plug-in used as 
the web server and maven-activemq-plugin used as the JMS broker.    


Pre-Requisites
==============

Apache Maven 2.X or 3.X



Running the Sample Service
=========================

1.) In a command line move to "samples/jms-sample/jmsService" directory  and run " mvn clean package activemq:run axis2:run"




Running the Sample Client
=========================





Help
====
Please contact java-user list (java-user@axis.apache.org) if you have any trouble running the sample.
